// Flint v3 - native C implementation / bytecode-style tree interpreter
// Module system, functions, namespaces, arrays, strings, booleans, control flow.
// Build with: cc -O3 -march=native -flto -DNDEBUG flint.c -o flint
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <math.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>

#define INITIAL_CAP 64
#define MAX_CALL 4096

typedef enum { V_INT, V_BOOL, V_STR, V_ARRAY, V_NULL } VType;
typedef struct Value Value;
typedef struct Array { Value *v; size_t n, cap; } Array;
struct Value { VType t; union { int64_t i; bool b; char *s; Array *a; } as; };
static Value vi(int64_t x){return (Value){V_INT,.as.i=x};}
static Value vb(bool x){return (Value){V_BOOL,.as.b=x};}
static Value vs(const char *s){Value v={V_STR}; v.as.s=strdup(s?s:""); return v;}
static Value vn(void){return (Value){V_NULL};}
static Value va(void){Value v={V_ARRAY}; v.as.a=calloc(1,sizeof(Array)); return v;}
static bool truth(Value v){return v.t==V_BOOL?v.as.b:v.t==V_INT?v.as.i!=0:v.t==V_STR?v.as.s[0]!=0:v.t==V_ARRAY?v.as.a->n!=0:false;}
static void vfree(Value v){ if(v.t==V_STR) free(v.as.s); else if(v.t==V_ARRAY){for(size_t i=0;i<v.as.a->n;i++)vfree(v.as.a->v[i]);free(v.as.a->v);free(v.as.a);} }
static Value vcopy(Value v){ if(v.t==V_STR)return vs(v.as.s); if(v.t==V_ARRAY){Value r=va();for(size_t i=0;i<v.as.a->n;i++){if(r.as.a->n==r.as.a->cap){r.as.a->cap=r.as.a->cap?r.as.a->cap*2:8;r.as.a->v=realloc(r.as.a->v,r.as.a->cap*sizeof(Value));}r.as.a->v[r.as.a->n++]=vcopy(v.as.a->v[i]);}return r;} return v; }

static void die_at(const char *file,int line,const char *msg){fprintf(stderr,"%s:%d: %s\n",file,line,msg);exit(1);}

// ---------------- lexer ----------------
typedef enum {T_EOF,T_NUM,T_STR,T_ID,T_FN,T_LET,T_IF,T_ELSE,T_WHILE,T_FOR,T_RETURN,T_PRINT,T_IMPORT,T_TRUE,T_FALSE,T_BREAK,T_CONTINUE,
 T_PLUS,T_MINUS,T_STAR,T_SLASH,T_MOD,T_EQ,T_EQEQ,T_NE,T_LT,T_GT,T_LE,T_GE,T_AND,T_OR,T_NOT,T_LP,T_RP,T_LB,T_RB,T_LS,T_RS,T_COMMA,T_SEMI,T_DOT} TokType;
typedef struct {TokType t; char *s; int64_t n; int line;} Tok;
typedef struct {Tok *v; size_t n,cap,pos; const char *file;} Lexer;
static void tokadd(Lexer*l,Tok t){if(l->n==l->cap){l->cap=l->cap?l->cap*2:256;l->v=realloc(l->v,l->cap*sizeof(Tok));}l->v[l->n++]=t;}
static char *dup_range(const char*a,const char*b){size_t n=(size_t)(b-a);char*s=malloc(n+1);memcpy(s,a,n);s[n]=0;return s;}
static void lex(Lexer*l,const char*src){
 int line=1; const char*p=src;
 while(*p){
  if(isspace((unsigned char)*p)){if(*p=='\n')line++;p++;continue;}
  if(*p=='#'){while(*p&&*p!='\n')p++;continue;}
  if(isdigit((unsigned char)*p)){char*e;long long n=strtoll(p,&e,10);tokadd(l,(Tok){T_NUM,NULL,n,line});p=e;continue;}
  if(isalpha((unsigned char)*p)||*p=='_'){
   const char*b=p++;while(isalnum((unsigned char)*p)||*p=='_')p++;char*s=dup_range(b,p);TokType t=T_ID;
   struct{const char*k;TokType t;}kw[]={{"fn",T_FN},{"let",T_LET},{"if",T_IF},{"else",T_ELSE},{"while",T_WHILE},{"for",T_FOR},{"return",T_RETURN},{"print",T_PRINT},{"import",T_IMPORT},{"true",T_TRUE},{"false",T_FALSE},{"break",T_BREAK},{"continue",T_CONTINUE}};
   for(size_t i=0;i<sizeof(kw)/sizeof(*kw);i++)if(!strcmp(s,kw[i].k)){t=kw[i].t;break;}tokadd(l,(Tok){t,s,0,line});continue;
  }
  if(*p=='"'){
   p++;size_t cap=64,n=0;char*buf=malloc(cap);
   while(*p&&*p!='"'){char c=*p++;if(c=='\\'&&*p){char e=*p++;if(e=='n')c='\n';else if(e=='t')c='\t';else c=e;}if(n+1>=cap){cap*=2;buf=realloc(buf,cap);}buf[n++]=c;}
   if(*p!='"')die_at(l->file,line,"unterminated string");p++;buf[n]=0;tokadd(l,(Tok){T_STR,buf,0,line});continue;
  }
  if(*p=='/'&&p[1]=='/'){p+=2;while(*p&&*p!='\n')p++;continue;}
  if(*p=='/' ){tokadd(l,(Tok){T_SLASH,NULL,0,line});p++;continue;}
  if(*p=='='&&p[1]=='='){tokadd(l,(Tok){T_EQEQ,NULL,0,line});p+=2;continue;} if(*p=='='){tokadd(l,(Tok){T_EQ,NULL,0,line});p++;continue;}
  if(*p=='!'&&p[1]=='='){tokadd(l,(Tok){T_NE,NULL,0,line});p+=2;continue;} if(*p=='!'){tokadd(l,(Tok){T_NOT,NULL,0,line});p++;continue;}
  if(*p=='<'&&p[1]=='='){tokadd(l,(Tok){T_LE,NULL,0,line});p+=2;continue;} if(*p=='<'){tokadd(l,(Tok){T_LT,NULL,0,line});p++;continue;}
  if(*p=='>'&&p[1]=='='){tokadd(l,(Tok){T_GE,NULL,0,line});p+=2;continue;} if(*p=='>'){tokadd(l,(Tok){T_GT,NULL,0,line});p++;continue;}
  if(*p=='&'&&p[1]=='&'){tokadd(l,(Tok){T_AND,NULL,0,line});p+=2;continue;}
  if(*p=='|'&&p[1]=='|'){tokadd(l,(Tok){T_OR,NULL,0,line});p+=2;continue;}
  TokType t=T_EOF;switch(*p){case '+':t=T_PLUS;break;case '-':t=T_MINUS;break;case '*':t=T_STAR;break;case '%':t=T_MOD;break;case '(':t=T_LP;break;case ')':t=T_RP;break;case '{':t=T_LB;break;case '}':t=T_RB;break;case '[':t=T_LS;break;case ']':t=T_RS;break;case ',':t=T_COMMA;break;case ';':t=T_SEMI;break;case '.':t=T_DOT;break;default:die_at(l->file,line,"unknown character");}tokadd(l,(Tok){t,NULL,0,line});p++;
 }
 tokadd(l,(Tok){T_EOF,NULL,0,line});
}

// ---------------- AST ----------------
typedef enum {N_NUM,N_STR,N_BOOL,N_VAR,N_ARRAY,N_INDEX,N_UNARY,N_BIN,N_ASSIGN,N_CALL,N_MEMBERCALL,N_FN,N_BLOCK,N_IF,N_WHILE,N_FOR,N_RETURN,N_PRINT,N_IMPORT,N_BREAK,N_CONTINUE,N_LET} NType;
typedef struct Node Node; typedef struct NodeList {Node**v;size_t n,cap;} NodeList;
struct Node {NType t; int line; char *name,*name2; int64_t num; bool b; char *str; Node *a,*bnode,*c; NodeList list,args;};
static Node*nn(NType t,int line){Node*n=calloc(1,sizeof(Node));n->t=t;n->line=line;return n;}
static void nadd(NodeList*l,Node*n){if(l->n==l->cap){l->cap=l->cap?l->cap*2:8;l->v=realloc(l->v,l->cap*sizeof(Node*));}l->v[l->n++]=n;}

typedef struct {Lexer l; const char*file;} Parser;
static Tok*pk(Parser*p){return &p->l.v[p->l.pos];} static bool is(Parser*p,TokType t){return pk(p)->t==t;} static Tok*take(Parser*p){return &p->l.v[p->l.pos++];}
static void need(Parser*p,TokType t,const char*msg){if(!is(p,t))die_at(p->file,pk(p)->line,msg);take(p);} 
static Node*expr(Parser*p); static Node*stmt(Parser*p);
static Node*primary(Parser*p){Tok*t=pk(p);if(is(p,T_NUM)){take(p);Node*n=nn(N_NUM,t->line);n->num=t->n;return n;}if(is(p,T_STR)){take(p);Node*n=nn(N_STR,t->line);n->str=strdup(t->s);return n;}if(is(p,T_TRUE)||is(p,T_FALSE)){take(p);Node*n=nn(N_BOOL,t->line);n->b=t->t==T_TRUE;return n;}if(is(p,T_ID)){take(p);Node*n=nn(N_VAR,t->line);n->name=strdup(t->s);return n;}if(is(p,T_LS)){take(p);Node*n=nn(N_ARRAY,t->line);if(!is(p,T_RS)){do{nadd(&n->args,expr(p));if(!is(p,T_COMMA))break;take(p);}while(1);}need(p,T_RS,"expected ]");return n;}if(is(p,T_LP)){take(p);Node*n=expr(p);need(p,T_RP,"expected )");return n;}die_at(p->file,t->line,"expected expression");return NULL;}
static Node*postfix(Parser*p){
    Node*n=primary(p);
    for(;;){
        if(n->t==N_VAR && is(p,T_DOT)){
            int line=pk(p)->line; take(p); Tok*m=pk(p); need(p,T_ID,"expected member name");
            char *mod=strdup(n->name), *member=strdup(m->s); free(n->name); n->name=NULL;
            if(!is(p,T_LP)) die_at(p->file,line,"expected ( after member name");
            take(p); Node*c=nn(N_MEMBERCALL,line); c->name=mod; c->name2=member;
            if(!is(p,T_RP)){do{nadd(&c->args,expr(p));if(!is(p,T_COMMA))break;take(p);}while(1);} need(p,T_RP,"expected )"); free(n); n=c; continue;
        }
        if(is(p,T_LP)){
            int line=pk(p)->line; take(p); Node*c=nn(N_CALL,line); c->a=n;
            if(!is(p,T_RP)){do{nadd(&c->args,expr(p));if(!is(p,T_COMMA))break;take(p);}while(1);} need(p,T_RP,"expected )"); n=c;
        } else if(is(p,T_LS)){
            int line=pk(p)->line; take(p); Node*c=nn(N_INDEX,line); c->a=n; c->bnode=expr(p); need(p,T_RS,"expected ]"); n=c;
        } else break;
    }
    return n;
}
static Node*unary(Parser*p){if(is(p,T_NOT)||is(p,T_MINUS)){Tok*t=take(p);Node*n=nn(N_UNARY,t->line);n->name=strdup(t->t==T_NOT?"!":"-");n->a=unary(p);return n;}return postfix(p);}
#define BIN(level,next,...) static Node*level(Parser*p){Node*n=next(p);for(;;){TokType tt=pk(p)->t;const char*op=NULL;__VA_ARGS__ if(!op)break;Tok*t=take(p);Node*r=nn(N_BIN,t->line);r->name=strdup(op);r->a=n;r->bnode=next(p);n=r;}return n;}
BIN(mult,unary, if(tt==T_STAR)op="*";else if(tt==T_SLASH)op="/";else if(tt==T_MOD)op="%";)
BIN(add,mult, if(tt==T_PLUS)op="+";else if(tt==T_MINUS)op="-";)
BIN(rel,add, if(tt==T_LT)op="<";else if(tt==T_GT)op=">";else if(tt==T_LE)op="<=";else if(tt==T_GE)op=">=";)
BIN(eq,rel, if(tt==T_EQEQ)op="==";else if(tt==T_NE)op="!=";)
BIN(andx,eq, if(tt==T_AND)op="&&";)
BIN(orx,andx, if(tt==T_OR)op="||";)
#undef BIN
static Node*expr(Parser*p){return orx(p);} 
static Node*block(Parser*p){Node*n=nn(N_BLOCK,pk(p)->line);need(p,T_LB,"expected {");while(!is(p,T_RB)&&!is(p,T_EOF))nadd(&n->list,stmt(p));need(p,T_RB,"expected }");return n;}
static Node*stmt(Parser*p){Tok*t=pk(p);if(is(p,T_IMPORT)){take(p);Tok*m=pk(p);need(p,T_ID,"expected module name");Node*n=nn(N_IMPORT,t->line);n->name=strdup(m->s);need(p,T_SEMI,"expected ;");return n;}if(is(p,T_FN)){take(p);Tok*nm=pk(p);need(p,T_ID,"expected function name");Node*n=nn(N_FN,t->line);n->name=strdup(nm->s);need(p,T_LP,"expected (");if(!is(p,T_RP)){do{Tok*a=pk(p);need(p,T_ID,"expected parameter");nadd(&n->args,(Node*)({Node*x=nn(N_VAR,a->line);x->name=strdup(a->s);x;}));if(!is(p,T_COMMA))break;take(p);}while(1);}need(p,T_RP,"expected )");n->a=block(p);return n;}if(is(p,T_LET)){take(p);Tok*nm=pk(p);need(p,T_ID,"expected variable");Node*n=nn(N_LET,t->line);n->name=strdup(nm->s);if(is(p,T_EQ)){take(p);n->a=expr(p);}need(p,T_SEMI,"expected ;");return n;}if(is(p,T_IF)){take(p);Node*n=nn(N_IF,t->line);need(p,T_LP,"expected (");n->a=expr(p);need(p,T_RP,"expected )");n->bnode=block(p);if(is(p,T_ELSE)){take(p);n->c=block(p);}return n;}if(is(p,T_WHILE)){take(p);Node*n=nn(N_WHILE,t->line);need(p,T_LP,"expected (");n->a=expr(p);need(p,T_RP,"expected )");n->bnode=block(p);return n;}if(is(p,T_FOR)){take(p);Node*n=nn(N_FOR,t->line);need(p,T_LP,"expected (");if(is(p,T_LET)){take(p);Tok*nm=pk(p);need(p,T_ID,"expected variable");n->a=nn(N_LET,nm->line);n->a->name=strdup(nm->s);need(p,T_EQ,"expected =");n->a->a=expr(p);}else n->a=stmt(p);need(p,T_SEMI,"expected ;");n->bnode=expr(p);need(p,T_SEMI,"expected ;");n->c=stmt(p);need(p,T_RP,"expected )");n->list.v=NULL;n->list.n=0;n->list.cap=0;n->list.v=realloc(NULL,sizeof(Node*));n->list.v[0]=block(p);n->list.n=1;n->list.cap=1;return n;}if(is(p,T_RETURN)){take(p);Node*n=nn(N_RETURN,t->line);if(!is(p,T_SEMI))n->a=expr(p);need(p,T_SEMI,"expected ;");return n;}if(is(p,T_PRINT)){take(p);Node*n=nn(N_PRINT,t->line);n->a=expr(p);need(p,T_SEMI,"expected ;");return n;}if(is(p,T_BREAK)||is(p,T_CONTINUE)){TokType tt=take(p)->t;Node*n=nn(tt==T_BREAK?N_BREAK:N_CONTINUE,t->line);need(p,T_SEMI,"expected ;");return n;}if(is(p,T_LB))return block(p);
 // assignment or expression statement
 Node*e=expr(p);if(is(p,T_EQ)){take(p);Node*n=nn(N_ASSIGN,t->line);n->a=e;n->bnode=expr(p);need(p,T_SEMI,"expected ;");return n;}need(p,T_SEMI,"expected ;");return e;}
static Node*parse_file(const char*file,const char*src){Parser p={0};p.file=file;p.l.file=file;lex(&p.l,src);Node*root=nn(N_BLOCK,1);while(!is(&p,T_EOF))nadd(&root->list,stmt(&p));return root;}

// ---------------- runtime ----------------
typedef struct Env Env; typedef struct Func Func; typedef struct Module Module;
typedef struct Var {char*name;Value v;} Var;
struct Env {Var*v;size_t n,cap;Env*parent;};
struct Func {char*name;Node*decl;Module*mod;};
struct Module {char*name;Node*root;Func*funcs;size_t fn,fc;Env globals;bool loaded;};
typedef struct {Module**mods;size_t n,cap;Module*cur;int depth;bool returned;Value ret;bool brk,cont;} Runtime;
static char g_stdlib[4096] = "stdlib";
static Value *lookup(Env*e,const char*n,bool create){for(Env*x=e;x;x=x->parent)for(size_t i=0;i<x->n;i++)if(!strcmp(x->v[i].name,n))return &x->v[i].v;if(!create)return NULL;if(e->n==e->cap){e->cap=e->cap?e->cap*2:16;e->v=realloc(e->v,e->cap*sizeof(Var));}e->v[e->n].name=strdup(n);e->v[e->n].v=vn();return &e->v[e->n++].v;}
static Func*findfunc(Module*m,const char*n){for(size_t i=0;i<m->fn;i++)if(!strcmp(m->funcs[i].name,n))return &m->funcs[i];return NULL;}
static char*readall(const char*path){FILE*f=fopen(path,"rb");if(!f){fprintf(stderr,"flint: cannot open %s: %s\n",path,strerror(errno));exit(1);}fseek(f,0,SEEK_END);long n=ftell(f);fseek(f,0,SEEK_SET);char*s=malloc((size_t)n+1);if(fread(s,1,n,f)!=(size_t)n){perror("read");exit(1);}s[n]=0;fclose(f);return s;}
static Module*getmod(Runtime*r,const char*name,const char*base);
static void collect_funcs(Module*m){for(size_t i=0;i<m->root->list.n;i++){Node*n=m->root->list.v[i];if(n->t==N_FN){if(m->fn==m->fc){m->fc=m->fc?m->fc*2:8;m->funcs=realloc(m->funcs,m->fc*sizeof(Func));}m->funcs[m->fn++]=(Func){strdup(n->name),n,m};}}}
static Value eval(Runtime*r,Env*e,Node*n);
static void exec(Runtime*r,Env*e,Node*n);
static Value callfn(Runtime*r,Func*f,Value*args,size_t na){if(++r->depth>MAX_CALL){fprintf(stderr,"flint: call stack overflow\n");exit(1);}Env env={0};env.parent=&f->mod->globals;for(size_t i=0;i<f->decl->args.n;i++){Value*v=lookup(&env,f->decl->args.v[i]->name,true);*v=i<na?vcopy(args[i]):vn();}r->returned=false;r->ret=vn();r->brk=r->cont=false;exec(r,&env,f->decl->a);Value out=vcopy(r->ret);r->returned=false;r->depth--;return out;}
static Value builtin_call(Runtime*r,const char*mod,const char*fn,Value*args,size_t na){if(!strcmp(mod,"__core")){if(!strcmp(fn,"__clock_us")){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return vi((int64_t)ts.tv_sec*1000000+ts.tv_nsec/1000);}if(!strcmp(fn,"print_raw")){if(na&&args[0].t==V_STR)fputs(args[0].as.s,stdout);return vn();}if(!strcmp(fn,"sqrt")){return vi((int64_t)sqrt((double)(na?args[0].as.i:0)));}if(!strcmp(fn,"len")){if(!na)return vi(0);if(args[0].t==V_STR)return vi((int64_t)strlen(args[0].as.s));if(args[0].t==V_ARRAY)return vi((int64_t)args[0].as.a->n);return vi(0);}}return vn();}
static Value member_call(Runtime*r,Node*n,Value*args,size_t na){Module*m=getmod(r,n->name,NULL);Func*f=findfunc(m,n->name2);if(!f){fprintf(stderr,"flint: %s.%s not found\n",n->name,n->name2);exit(1);}return callfn(r,f,args,na);}
static Value eval(Runtime*r,Env*e,Node*n){if(!n)return vn();switch(n->t){case N_NUM:return vi(n->num);case N_BOOL:return vb(n->b);case N_STR:return vs(n->str);case N_VAR:{Value*v=lookup(e,n->name,false);if(!v){fprintf(stderr,"flint:%d: undefined variable %s\n",n->line,n->name);exit(1);}return vcopy(*v);}case N_ARRAY:{Value a=va();for(size_t i=0;i<n->args.n;i++){Value x=eval(r,e,n->args.v[i]);a.as.a->v=realloc(a.as.a->v,(a.as.a->n+1)*sizeof(Value));a.as.a->v[a.as.a->n++]=x;}return a;}case N_INDEX:{Value a=eval(r,e,n->a),ix=eval(r,e,n->bnode);if(a.t!=V_ARRAY||ix.t!=V_INT||ix.as.i<0||(size_t)ix.as.i>=a.as.a->n){fprintf(stderr,"flint:%d: invalid index\n",n->line);exit(1);}Value out=vcopy(a.as.a->v[ix.as.i]);vfree(a);vfree(ix);return out;}case N_UNARY:{Value x=eval(r,e,n->a);Value o=!strcmp(n->name,"!")?vb(!truth(x)):vi(-x.as.i);vfree(x);return o;}case N_BIN:{Value a=eval(r,e,n->a);if(!strcmp(n->name,"&&")&&!truth(a)){vfree(a);return vb(false);}if(!strcmp(n->name,"||")&&truth(a)){vfree(a);return vb(true);}Value b=eval(r,e,n->bnode);Value o=vn();if(!strcmp(n->name,"+"))o=vi(a.as.i+b.as.i);else if(!strcmp(n->name,"-"))o=vi(a.as.i-b.as.i);else if(!strcmp(n->name,"*"))o=vi(a.as.i*b.as.i);else if(!strcmp(n->name,"/")){if(!b.as.i)die_at(r->cur->name,n->line,"division by zero");o=vi(a.as.i/b.as.i);}else if(!strcmp(n->name,"%")){if(!b.as.i)die_at(r->cur->name,n->line,"division by zero");o=vi(a.as.i%b.as.i);}else if(!strcmp(n->name,"=="))o=vb(a.t==b.t&&(a.t==V_INT?a.as.i==b.as.i:a.t==V_BOOL?a.as.b==b.as.b:a.t==V_STR&&!strcmp(a.as.s,b.as.s)));else if(!strcmp(n->name,"!="))o=vb(!(a.t==b.t&&(a.t==V_INT?a.as.i==b.as.i:a.t==V_BOOL?a.as.b==b.as.b:a.t==V_STR&&!strcmp(a.as.s,b.as.s))));else if(!strcmp(n->name,"<"))o=vb(a.as.i<b.as.i);else if(!strcmp(n->name,">"))o=vb(a.as.i>b.as.i);else if(!strcmp(n->name,"<="))o=vb(a.as.i<=b.as.i);else if(!strcmp(n->name,">="))o=vb(a.as.i>=b.as.i);else if(!strcmp(n->name,"&&"))o=vb(truth(a)&&truth(b));else if(!strcmp(n->name,"||"))o=vb(truth(a)||truth(b));vfree(a);vfree(b);return o;}case N_ASSIGN:{Value x=eval(r,e,n->bnode);if(n->a->t==N_VAR){Value*v=lookup(e,n->a->name,true);vfree(*v);*v=vcopy(x);}else if(n->a->t==N_INDEX){/* simplified array assignment */Value arr=eval(r,e,n->a->a),ix=eval(r,e,n->a->bnode);if(arr.t!=V_ARRAY||ix.t!=V_INT||ix.as.i<0||(size_t)ix.as.i>=arr.as.a->n)die_at(r->cur->name,n->line,"invalid assignment index");vfree(arr.as.a->v[ix.as.i]);arr.as.a->v[ix.as.i]=vcopy(x);vfree(arr);vfree(ix);}else die_at(r->cur->name,n->line,"invalid assignment target");return x;}case N_CALL:{if(n->a->t!=N_VAR)die_at(r->cur->name,n->line,"call target must be function");Func*f=findfunc(r->cur,n->a->name);if(!f){/* core helpers */Value*args=calloc(n->args.n,sizeof(Value));for(size_t i=0;i<n->args.n;i++)args[i]=eval(r,e,n->args.v[i]);Value o=builtin_call(r,"__core",n->a->name,args,n->args.n);for(size_t i=0;i<n->args.n;i++)vfree(args[i]);free(args);return o;}Value*args=calloc(n->args.n,sizeof(Value));for(size_t i=0;i<n->args.n;i++)args[i]=eval(r,e,n->args.v[i]);Value o=callfn(r,f,args,n->args.n);for(size_t i=0;i<n->args.n;i++)vfree(args[i]);free(args);return o;}case N_MEMBERCALL:{Value*args=calloc(n->args.n,sizeof(Value));for(size_t i=0;i<n->args.n;i++)args[i]=eval(r,e,n->args.v[i]);Value o=member_call(r,n,args,n->args.n);for(size_t i=0;i<n->args.n;i++)vfree(args[i]);free(args);return o;}default:break;}return vn();}
static void exec(Runtime*r,Env*e,Node*n){if(!n||r->returned)return;switch(n->t){case N_BLOCK:for(size_t i=0;i<n->list.n&&!r->returned;i++){exec(r,e,n->list.v[i]);if(r->brk||r->cont)break;}break;case N_FN:break;case N_IMPORT:getmod(r,n->name,NULL);break;case N_LET:{Value*v=lookup(e,n->name,true);if(n->a){vfree(*v);*v=eval(r,e,n->a);}break;}case N_PRINT:{Value v=eval(r,e,n->a);if(v.t==V_INT)printf("%lld\n",(long long)v.as.i);else if(v.t==V_BOOL)printf("%s\n",v.as.b?"true":"false");else if(v.t==V_STR)printf("%s\n",v.as.s);else if(v.t==V_ARRAY)printf("[array:%zu]\n",v.as.a->n);vfree(v);break;}case N_IF:{Value c=eval(r,e,n->a);if(truth(c))exec(r,e,n->bnode);else exec(r,e,n->c);vfree(c);break;}case N_WHILE:while(1){Value c=eval(r,e,n->a);bool ok=truth(c);vfree(c);if(!ok)break;exec(r,e,n->bnode);if(r->returned)break;if(r->brk){r->brk=false;break;}if(r->cont){r->cont=false;continue;}}break;case N_FOR:{exec(r,e,n->a);while(1){Value c=eval(r,e,n->bnode);bool ok=truth(c);vfree(c);if(!ok)break;exec(r,e,n->list.v[0]);if(r->returned)break;if(r->brk){r->brk=false;break;}if(r->cont)r->cont=false;exec(r,e,n->c);}break;}case N_RETURN:r->ret=n->a?eval(r,e,n->a):vn();r->returned=true;break;case N_BREAK:r->brk=true;break;case N_CONTINUE:r->cont=true;break;default:(void)eval(r,e,n);break;}}
static char*dirname_of(const char*p){char*s=strdup(p);char*q=strrchr(s,'/');if(q)*q=0;else strcpy(s,".");return s;}
static Module*getmod(Runtime*r,const char*name,const char*base){for(size_t i=0;i<r->n;i++)if(!strcmp(r->mods[i]->name,name))return r->mods[i];char path[4096];bool builtin=!strcmp(name,"time")||!strcmp(name,"math")||!strcmp(name,"strings")||!strcmp(name,"array")||!strcmp(name,"print");if(builtin)snprintf(path,sizeof(path),"%s/%s.fl",g_stdlib,name);else if(base){snprintf(path,sizeof(path),"%s/%s.fl",base,name);if(access(path,F_OK)!=0)snprintf(path,sizeof(path),"%s/%s.fl",g_stdlib,name);}else snprintf(path,sizeof(path),"%s/%s.fl",g_stdlib,name);char*src=readall(path);Module*m=calloc(1,sizeof(Module));m->name=strdup(name);m->root=parse_file(path,src);m->globals.parent=NULL; if(r->n==r->cap){r->cap=r->cap?r->cap*2:8;r->mods=realloc(r->mods,r->cap*sizeof(Module*));}r->mods[r->n++]=m;collect_funcs(m);m->loaded=true; // process imports and top-level initialization
 char*dir=dirname_of(path);Module*old=r->cur;r->cur=m;for(size_t i=0;i<m->root->list.n;i++){Node*n=m->root->list.v[i];if(n->t==N_IMPORT)getmod(r,n->name,dir);}for(size_t i=0;i<m->root->list.n;i++){Node*n=m->root->list.v[i];if(n->t!=N_FN&&n->t!=N_IMPORT)exec(r,&m->globals,n);}r->cur=old;free(dir);free(src);return m;}

int main(int argc,char**argv){if(argc!=2){fprintf(stderr,"usage: flint <program.fl>\n");return 2;}const char*envstd=getenv("FLINT_STDLIB");if(envstd&&*envstd){snprintf(g_stdlib,sizeof(g_stdlib),"%s",envstd);}else{char*bd=dirname_of(argv[0]);snprintf(g_stdlib,sizeof(g_stdlib),"%s/stdlib",bd);free(bd);}Runtime r={0};char*src=readall(argv[1]);Module mainm={0};mainm.name=strdup("main");mainm.root=parse_file(argv[1],src);mainm.globals.parent=NULL;if(r.n==r.cap){r.cap=8;r.mods=calloc(r.cap,sizeof(Module*));}r.mods[r.n++]=&mainm;r.cur=&mainm;collect_funcs(&mainm);char*dir=dirname_of(argv[1]);for(size_t i=0;i<mainm.root->list.n;i++){Node*n=mainm.root->list.v[i];if(n->t==N_IMPORT)getmod(&r,n->name,dir);}for(size_t i=0;i<mainm.root->list.n;i++){Node*n=mainm.root->list.v[i];if(n->t!=N_FN&&n->t!=N_IMPORT)exec(&r,&mainm.globals,n);}free(dir);free(src);return 0;}
