# Flint v3 architecture

```text
source
  -> lexer
  -> recursive-descent parser
  -> AST
  -> module loader / namespace resolver
  -> optimized C runtime
```

Modules are cached by name. A module has its own global environment, so state in `time.fl` remains private to the module while its functions are callable through `time.start()` and `time.stop()`.

The five standard modules are source-level Flint modules. This is deliberate: library code should be written in Flint whenever possible, while the runtime exposes only minimal platform primitives.

## Performance direction

v3 is compiled with `-O3 -march=native -flto -DNDEBUG`. The current runtime is still an interpreter, so it cannot honestly beat optimized native C/C++ for tight numeric loops. The next performance layer is a bytecode VM with direct-threaded dispatch, followed by an x86-64 native backend/JIT. That is the path to native-code performance.
