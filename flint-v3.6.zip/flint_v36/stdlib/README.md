# Flint standard library

These modules are intentionally written in Flint. They are ordinary modules and can be inspected, copied, modified, or replaced.

The runtime only exposes a tiny low-level primitive for `time`: `__clock_ms()`.
