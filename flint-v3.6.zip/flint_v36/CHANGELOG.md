# Flint v3 changes

- Added ordinary user modules: `import geometry;` and `geometry.area(...)`.
- Added namespace member calls: `module.function(...)`.
- Added module-local global state.
- Added five source-level standard modules: `time`, `math`, `strings`, `array`, `print`.
- Added `time.start()`, `time.stop()`, and `time.now()`.
- Added strings, arrays, booleans, `let`, functions, recursion, returns, loops, break/continue.
- Preserved the original all-assembly Flint interpreter under `legacy/`.
- Built v3 with `-O3 -march=native -flto -DNDEBUG`.
- Added smoke tests and examples.

## Performance status

v3 is still an interpreter. The optimized C host improves the implementation, but it does not make Flint source faster than native C/C++ or hand-written machine code. The honest path to that goal is bytecode/JIT/native x86-64 code generation, which is the next compiler phase.
