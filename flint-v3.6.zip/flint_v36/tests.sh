#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
./flint examples/module_math.fl | grep -qx '144'
./flint examples/module_math.fl | tail -1 | grep -qx '9'
./flint examples/user_module.fl | grep -qx '300'
out=$(./flint examples/time.fl)
case "$out" in ''|*[!0-9]*) echo "bad time result: $out"; exit 1;; esac
printf 'Flint v3 smoke tests passed.\n'
