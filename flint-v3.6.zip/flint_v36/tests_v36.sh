#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cc -O3 -march=native -flto -DNDEBUG "$ROOT/flint.c" -lm -o "$ROOT/flint.test"
cc -O3 -march=native -flto -DNDEBUG "$ROOT/flintc.c" -lm -o "$ROOT/flintc.test"

[ "$("$ROOT/flint.test" "$ROOT/examples/functions.fl")" = "55" ]
[ "$("$ROOT/flintc.test" "$ROOT/examples/native35.fl" -o /tmp/flint-v36-native && /tmp/flint-v36-native)" = "42
144
45" ]
cat >/tmp/flint-v36-opt.fl <<'F'
let x = 10 * 20 + 5;
if (1 == 1) { print x + 0; } else { print 999; }
while (false) { print 123; }
print 7 * 8;
F
[ "$("$ROOT/flintc.test" /tmp/flint-v36-opt.fl -o /tmp/flint-v36-opt && /tmp/flint-v36-opt)" = "205
56" ]
rm -f "$ROOT/flint.test" "$ROOT/flintc.test" /tmp/flint-v36-native /tmp/flint-v36-opt /tmp/flint-v36-opt.fl
printf 'Flint v3.6 tests passed.\n'
