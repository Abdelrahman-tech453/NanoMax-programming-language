# Flint v3.6

Flint v3.6 is the native-performance milestone after v3.5.

## Toolchain

- `flint` — complete v3 interpreter and language reference
- `flintc` — native x86-64 ahead-of-time compiler

## Native pipeline

```text
source → lexer/parser → AST → optimizer → x86-64 assembly → ELF
```

The optimizer currently performs:

- constant folding
- literal boolean simplification
- constant `if` pruning
- `while(false)` elimination
- dead statements after `return`/`break`/`continue`
- arithmetic identities

Example:

```flint
let x = 10 * 20 + 5;
if (1 == 1) {
    print x + 0;
}
print 7 * 8;
```

The native compiler reduces the compile-time expressions to constants and emits native code for the remaining program.

## Build

```sh
make
```

## Native compile

```sh
./flintc program.fl -o program
./program
```

Inspect assembly:

```sh
./flintc --emit-asm program.fl -o program.s
```

## Honest performance status

v3.6 is **not claimed to beat optimized C/C++**. It removes interpreter overhead and now performs compile-time optimization, but mature C/C++ compilers still have substantially more advanced optimization pipelines.

The next milestone is a real SSA IR with basic blocks, liveness, register allocation, inlining, alias analysis, and SIMD lowering.
