# Flint v3.6 optimizer

v3.6 adds a compile-time optimization pass before the native x86-64 backend.

Implemented now:
- recursive constant folding for integer/boolean expressions
- constant propagation through literal `if` conditions
- removal of `while(false)` loops
- boolean simplification for literal `&&` / `||`
- algebraic identities (`x + 0`, `x - 0`, `x * 1`, `x * 0` when safe)
- power-of-two multiplication lowering (`x * 2^n` -> `x << n`) where represented safely
- dead statement removal after `return`, `break`, and `continue`
- `for` lowering to the existing native loop machinery

This is intentionally a pre-IR optimization stage. The next compiler milestone should replace this AST pass with SSA IR and a real register allocator.
