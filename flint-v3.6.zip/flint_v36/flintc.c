#define main flint_interpreter_main
#include "flint.c"
#include <stdarg.h>
#undef main

/* Flint v3.5 native x86-64 backend.
 * This is deliberately small and honest: it AOT-compiles the integer/control-flow/function
 * subset to System V AMD64 assembly. The full v3 interpreter remains the language reference.
 */
typedef struct { char *name; int off; } CVar;
typedef struct { CVar *v; size_t n, cap; int slots; } CEnv;
typedef struct { FILE *f; int label; int ret_label; CEnv env; const char *file; } CG;

static void cenv_add(CEnv *e, const char *name) {
    for(size_t i=0;i<e->n;i++) if(!strcmp(e->v[i].name,name)) return;
    if(e->n==e->cap){e->cap=e->cap?e->cap*2:16;e->v=realloc(e->v,e->cap*sizeof(CVar));}
    e->v[e->n].name=strdup(name); e->v[e->n].off=-(++e->slots)*8; e->n++;
}
static int cenv_find(CEnv *e,const char *name){for(size_t i=0;i<e->n;i++)if(!strcmp(e->v[i].name,name))return e->v[i].off;return 0;}
static void scan_node(CEnv *e, Node *n){
    if(!n)return;
    if(n->t==N_LET)cenv_add(e,n->name);
    if(n->t==N_ASSIGN && n->a && n->a->t==N_VAR)cenv_add(e,n->a->name);
    if(n->t==N_VAR)cenv_add(e,n->name);
    for(size_t i=0;i<n->list.n;i++)scan_node(e,n->list.v[i]);
    for(size_t i=0;i<n->args.n;i++)scan_node(e,n->args.v[i]);
    scan_node(e,n->a);scan_node(e,n->bnode);scan_node(e,n->c);
}
static void emit(CG*c,const char*fmt,...){va_list ap;va_start(ap,fmt);vfprintf(c->f,fmt,ap);va_end(ap);}
static int lbl(CG*c){return c->label++;}
static void unsupported(CG*c,Node*n,const char*what){fprintf(stderr,"flintc: %s:%d: unsupported in native backend: %s\n",c->file,n?n->line:0,what);exit(1);}

static void gen_expr(CG*c,Node*n);
static void gen_stmt(CG*c,Node*n);

/* ---------------- v3.6 AST optimizer ---------------- */
static Node *opt_expr(Node *n);
static void opt_stmt(Node *n);

static bool is_num(Node *n, int64_t *v) { if (n && n->t==N_NUM) { *v=n->num; return true; } return false; }
static bool is_bool(Node *n, bool *v) { if (n && n->t==N_BOOL) { *v=n->b; return true; } return false; }

static Node *mk_num_like(Node *old, int64_t v) { Node *r=nn(N_NUM, old?old->line:1); r->num=v; return r; }
static Node *mk_bool_like(Node *old, bool v) { Node *r=nn(N_BOOL, old?old->line:1); r->b=v; return r; }

static Node *opt_expr(Node *n) {
    if (!n) return NULL;
    if (n->a) n->a=opt_expr(n->a);
    if (n->bnode) n->bnode=opt_expr(n->bnode);
    if (n->c) n->c=opt_expr(n->c);
    for(size_t i=0;i<n->args.n;i++) n->args.v[i]=opt_expr(n->args.v[i]);

    if(n->t==N_UNARY) {
        int64_t x; bool b;
        if(!strcmp(n->name,"-") && is_num(n->a,&x)) return mk_num_like(n,-x);
        if(!strcmp(n->name,"!") && is_bool(n->a,&b)) return mk_bool_like(n,!b);
        if(!strcmp(n->name,"!") && is_num(n->a,&x)) return mk_bool_like(n,x==0);
    }
    if(n->t==N_BIN) {
        int64_t a,b;
        bool ba,bb;
        if(is_num(n->a,&a) && is_num(n->bnode,&b)) {
            if(!strcmp(n->name,"+")) return mk_num_like(n,a+b);
            if(!strcmp(n->name,"-")) return mk_num_like(n,a-b);
            if(!strcmp(n->name,"*")) return mk_num_like(n,a*b);
            if(!strcmp(n->name,"/") && b) return mk_num_like(n,a/b);
            if(!strcmp(n->name,"%") && b) return mk_num_like(n,a%b);
            if(!strcmp(n->name,"==")) return mk_bool_like(n,a==b);
            if(!strcmp(n->name,"!=")) return mk_bool_like(n,a!=b);
            if(!strcmp(n->name,"<")) return mk_bool_like(n,a<b);
            if(!strcmp(n->name,">")) return mk_bool_like(n,a>b);
            if(!strcmp(n->name,"<=")) return mk_bool_like(n,a<=b);
            if(!strcmp(n->name,">=")) return mk_bool_like(n,a>=b);
        }
        if(is_bool(n->a,&ba) && is_bool(n->bnode,&bb)) {
            if(!strcmp(n->name,"&&")) return mk_bool_like(n,ba&&bb);
            if(!strcmp(n->name,"||")) return mk_bool_like(n,ba||bb);
            if(!strcmp(n->name,"==")) return mk_bool_like(n,ba==bb);
            if(!strcmp(n->name,"!=")) return mk_bool_like(n,ba!=bb);
        }
        /* Short-circuit simplification is safe because the right side is only
           observed when required by the language's short-circuit semantics. */
        if(!strcmp(n->name,"&&")) {
            if(is_bool(n->a,&ba)) return ba ? n->bnode : mk_bool_like(n,false);
            if(is_num(n->a,&a)) return a ? n->bnode : mk_bool_like(n,false);
        }
        if(!strcmp(n->name,"||")) {
            if(is_bool(n->a,&ba)) return ba ? mk_bool_like(n,true) : n->bnode;
            if(is_num(n->a,&a)) return a ? mk_bool_like(n,true) : n->bnode;
        }
        /* Safe arithmetic identities. */
        if(is_num(n->bnode,&b)) {
            if(!strcmp(n->name,"+") && b==0) return n->a;
            if(!strcmp(n->name,"-") && b==0) return n->a;
            if(!strcmp(n->name,"*") && b==1) return n->a;
            if(!strcmp(n->name,"/") && b==1) return n->a;
            if(!strcmp(n->name,"*") && b==0) return mk_num_like(n,0);
        }
        if(is_num(n->a,&a)) {
            if(!strcmp(n->name,"+") && a==0) return n->bnode;
            if(!strcmp(n->name,"*") && a==1) return n->bnode;
            if(!strcmp(n->name,"*") && a==0) return mk_num_like(n,0);
        }
    }
    return n;
}

static bool stmt_terminates(Node *n) {
    if(!n) return false;
    return n->t==N_RETURN || n->t==N_BREAK || n->t==N_CONTINUE;
}

static void opt_stmt(Node *n) {
    if(!n) return;
    switch(n->t) {
    case N_BLOCK: {
        size_t w=0;
        bool dead=false;
        for(size_t i=0;i<n->list.n;i++) {
            Node *s=n->list.v[i];
            if(dead) continue;
            opt_stmt(s);
            n->list.v[w++]=s;
            if(stmt_terminates(s)) dead=true;
        }
        n->list.n=w;
        break;
    }
    case N_FN: opt_stmt(n->a); break;
    case N_LET: n->a=opt_expr(n->a); break;
    case N_IF: {
        n->a=opt_expr(n->a); opt_stmt(n->bnode); opt_stmt(n->c);
        bool b; int64_t x;
        if(is_bool(n->a,&b)) {
            Node *chosen=b?n->bnode:n->c;
            if(!chosen) { n->t=N_BLOCK; n->list.n=0; n->a=n->bnode=n->c=NULL; }
            else { Node tmp=*chosen; *n=tmp; }
        } else if(is_num(n->a,&x)) {
            Node *chosen=x?n->bnode:n->c;
            if(!chosen) { n->t=N_BLOCK; n->list.n=0; n->a=n->bnode=n->c=NULL; }
            else { Node tmp=*chosen; *n=tmp; }
        }
        break;
    }
    case N_WHILE: {
        n->a=opt_expr(n->a); opt_stmt(n->bnode);
        bool b; int64_t x;
        if((is_bool(n->a,&b)&&!b)||(is_num(n->a,&x)&&x==0)) { n->t=N_BLOCK; n->list.n=0; n->a=n->bnode=n->c=NULL; }
        break;
    }
    case N_FOR:
        opt_stmt(n->a); n->bnode=opt_expr(n->bnode); opt_stmt(n->c); if(n->list.n) opt_stmt(n->list.v[0]); break;
    case N_RETURN: n->a=opt_expr(n->a); break;
    case N_PRINT: n->a=opt_expr(n->a); break;
    case N_IMPORT: case N_BREAK: case N_CONTINUE: break;
    default: (void)opt_expr(n); break;
    }
}

static void optimize_program(Node *root) {
    opt_stmt(root);
}


static void gen_expr(CG*c,Node*n){
    if(!n) {emit(c,"  xor %%eax, %%eax\n");return;}
    switch(n->t){
    case N_NUM: emit(c,"  mov $%lld, %%rax\n",(long long)n->num); return;
    case N_BOOL: emit(c,"  mov $%d, %%rax\n",n->b?1:0); return;
    case N_VAR:{int o=cenv_find(&c->env,n->name);if(!o)unsupported(c,n,"unknown variable");emit(c,"  mov %d(%%rbp), %%rax\n",o);return;}
    case N_UNARY: gen_expr(c,n->a); if(!strcmp(n->name,"-"))emit(c,"  neg %%rax\n"); else if(!strcmp(n->name,"!")){emit(c,"  cmp $0, %%rax\n  sete %%al\n  movzx %%al, %%rax\n");} else unsupported(c,n,"unary operator"); return;
    case N_BIN:{
        int L1=lbl(c),L2=lbl(c);
        gen_expr(c,n->a); emit(c,"  push %%rax\n"); gen_expr(c,n->bnode); emit(c,"  mov %%rax, %%rcx\n  pop %%rax\n");
        if(!strcmp(n->name,"+"))emit(c,"  add %%rcx, %%rax\n");
        else if(!strcmp(n->name,"-"))emit(c,"  sub %%rcx, %%rax\n");
        else if(!strcmp(n->name,"*"))emit(c,"  imul %%rcx, %%rax\n");
        else if(!strcmp(n->name,"/")){emit(c,"  cqo\n  idiv %%rcx\n");}
        else if(!strcmp(n->name,"%")){emit(c,"  cqo\n  idiv %%rcx\n  mov %%rdx, %%rax\n");}
        else if(!strcmp(n->name,"&&")){emit(c,"  test %%rax, %%rax\n  jz .Lfalse%d\n  test %%rcx, %%rcx\n  jz .Lfalse%d\n  mov $1, %%rax\n  jmp .Ldone%d\n.Lfalse%d:\n  xor %%eax, %%eax\n.Ldone%d:\n",L1,L1,L2,L1,L2);}
        else if(!strcmp(n->name,"||")){emit(c,"  test %%rax, %%rax\n  jnz .Ltrue%d\n  test %%rcx, %%rcx\n  jnz .Ltrue%d\n  xor %%eax, %%eax\n  jmp .Ldone%d\n.Ltrue%d:\n  mov $1, %%rax\n.Ldone%d:\n",L1,L1,L2,L1,L2);}
        else {const char *j=!strcmp(n->name,"==")?"e":!strcmp(n->name,"!=")?"ne":!strcmp(n->name,"<")?"l":!strcmp(n->name,">")?"g":!strcmp(n->name,"<=")?"le":!strcmp(n->name,">=")?"ge":NULL;if(!j)unsupported(c,n,"binary operator");emit(c,"  cmp %%rcx, %%rax\n  set%s %%al\n  movzx %%al, %%rax\n",j);}
        return; }
    case N_ASSIGN: if(n->a->t!=N_VAR)unsupported(c,n,"non-variable assignment");gen_expr(c,n->bnode);{int o=cenv_find(&c->env,n->a->name);if(!o)cenv_add(&c->env,n->a->name),o=cenv_find(&c->env,n->a->name);emit(c,"  mov %%rax, %d(%%rbp)\n",o);}return;
    case N_CALL:{
        static const char *regs[]={"%rdi","%rsi","%rdx","%rcx","%r8","%r9"};
        if(n->args.n>6)unsupported(c,n,"more than 6 call arguments");
        for(size_t i=0;i<n->args.n;i++){gen_expr(c,n->args.v[i]);emit(c,"  push %%rax\n");}
        for(size_t i=n->args.n;i>0;i--)emit(c,"  pop %s\n",regs[i-1]);
        if(n->a->t!=N_VAR)unsupported(c,n,"indirect call");
        emit(c,"  call flint_fn_%s\n",n->a->name); return; }
    default: unsupported(c,n,"expression node");
    }
}
static void gen_stmt(CG*c,Node*n){
    if(!n)return;
    switch(n->t){
    case N_BLOCK:for(size_t i=0;i<n->list.n;i++)gen_stmt(c,n->list.v[i]);break;
    case N_FN: break;
    case N_LET: if(n->a)gen_expr(c,n->a);else emit(c,"  xor %%eax, %%eax\n"); {int o=cenv_find(&c->env,n->name);if(!o){cenv_add(&c->env,n->name);o=cenv_find(&c->env,n->name);}emit(c,"  mov %%rax, %d(%%rbp)\n",o);}break;
    case N_PRINT:gen_expr(c,n->a);emit(c,"  call flint_print_i64\n");break;
    case N_RETURN:if(n->a)gen_expr(c,n->a);else emit(c,"  xor %%eax, %%eax\n");emit(c,"  jmp .Lret%d\n",c->ret_label);break;
    case N_IF:{int e=lbl(c),done=lbl(c);gen_expr(c,n->a);emit(c,"  test %%rax, %%rax\n  jz .Lelse%d\n",e);gen_stmt(c,n->bnode);emit(c,"  jmp .Lend%d\n.Lelse%d:\n",done,e);if(n->c)gen_stmt(c,n->c);emit(c,".Lend%d:\n",done);break;}
    case N_WHILE:{int a=lbl(c),done=lbl(c);emit(c,".Lwhile%d:\n",a);gen_expr(c,n->a);emit(c,"  test %%rax, %%rax\n  jz .Lendwhile%d\n",done);gen_stmt(c,n->bnode);emit(c,"  jmp .Lwhile%d\n.Lendwhile%d:\n",a,done);break;}
    default: if(n->t==N_IMPORT)unsupported(c,n,"imports in native backend (compile modules separately in v3.6)"); else {gen_expr(c,n);emit(c,"\n");}break;
    }
}
static void gen_function(CG*c,Node*n){
    CEnv saved=c->env; memset(&c->env,0,sizeof(c->env));
    for(size_t i=0;i<n->args.n;i++)cenv_add(&c->env,n->args.v[i]->name);
    scan_node(&c->env,n->a);
    int frame=((c->env.slots*8+15)/16)*16;
    emit(c,".globl flint_fn_%s\nflint_fn_%s:\n  push %%rbp\n  mov %%rsp, %%rbp\n",n->name,n->name);
    if(frame)emit(c,"  sub $%d, %%rsp\n",frame);
    static const char*regs[]={"%rdi","%rsi","%rdx","%rcx","%r8","%r9"};
    for(size_t i=0;i<n->args.n;i++){int o=cenv_find(&c->env,n->args.v[i]->name);emit(c,"  mov %s, %d(%%rbp)\n",regs[i],o);}
    int ret=lbl(c); int oldret=c->ret_label; c->ret_label=ret; gen_stmt(c,n->a); emit(c,".Lret%d:\n",ret);emit(c,"  leave\n  ret\n");
    c->ret_label=oldret; c->env=saved;
}

static int compile_native(const char *srcfile,const char *asmfile){
    char *src=readall(srcfile);Node *root=parse_file(srcfile,src);optimize_program(root);FILE*f=fopen(asmfile,"w");if(!f){perror(asmfile);return 1;}
    CG c={.f=f,.label=1,.file=srcfile};
    emit(&c,".text\n");
    for(size_t i=0;i<root->list.n;i++)if(root->list.v[i]->t==N_FN)gen_function(&c,root->list.v[i]);
    memset(&c.env,0,sizeof(c.env));scan_node(&c.env,root);
    int frame=((c.env.slots*8+15)/16)*16;
    emit(&c,".globl flint_main\nflint_main:\n  push %%rbp\n  mov %%rsp, %%rbp\n");if(frame)emit(&c,"  sub $%d, %%rsp\n",frame);
    for(size_t i=0;i<root->list.n;i++)if(root->list.v[i]->t!=N_FN)gen_stmt(&c,root->list.v[i]);
    emit(&c,"  xor %%eax, %%eax\n  leave\n  ret\n\n");
    emit(&c,".globl _start\n_start:\n  call flint_main\n  mov %%eax, %%edi\n  mov $60, %%eax\n  syscall\n\n");
    emit(&c,".section .rodata\nminus: .ascii \"-\"\nnewline: .ascii \"\\n\"\n\n.text\n.globl flint_print_i64\nflint_print_i64:\n  push %%rbp\n  mov %%rsp, %%rbp\n  sub $64, %%rsp\n  mov %%rax, %%r8\n  lea 63(%%rsp), %%rsi\n  movb $10, (%%rsi)\n  dec %%rsi\n  xor %%ecx, %%ecx\n  cmp $0, %%r8\n  jne .Lpi_nonzero\n  movb $'0', (%%rsi)\n  dec %%rsi\n  jmp .Lpi_write\n.Lpi_nonzero:\n  xor %%r9d, %%r9d\n  cmp $0, %%r8\n  jge .Lpi_loop\n  neg %%r8\n  mov $1, %%r9d\n.Lpi_loop:\n  mov %%r8, %%rax\n  xor %%edx, %%edx\n  mov $10, %%r10\n  div %%r10\n  add $'0', %%dl\n  mov %%dl, (%%rsi)\n  dec %%rsi\n  mov %%rax, %%r8\n  test %%rax, %%rax\n  jnz .Lpi_loop\n  test %%r9d, %%r9d\n  jz .Lpi_write\n  movb $'-', (%%rsi)\n  dec %%rsi\n.Lpi_write:\n  lea 1(%%rsi), %%rsi\n  lea 64(%%rsp), %%rdx\n  sub %%rsi, %%rdx\n  mov $1, %%edi\n  mov $1, %%eax\n  syscall\n  leave\n  ret\n");
    fclose(f);free(src);return 0;
}

int main(int argc,char**argv){
    if(argc<2){fprintf(stderr,"usage: flintc <program.fl> [-o output]\n       flintc --emit-asm <program.fl> [-o output.s]\n");return 2;}
    const char *src=NULL,*out=NULL;bool emit_only=false;
    for(int i=1;i<argc;i++){if(!strcmp(argv[i],"--emit-asm")){emit_only=true;continue;}if(!strcmp(argv[i],"-o")&&i+1<argc){out=argv[++i];continue;}if(argv[i][0]!='-')src=argv[i];}
    if(!src){fprintf(stderr,"flintc: missing source\n");return 2;}
    char tmp[4096];if(!out){snprintf(tmp,sizeof(tmp),"%s",emit_only?"a.s":"a.out");out=tmp;}
    char asmpath[4096];if(emit_only)snprintf(asmpath,sizeof(asmpath),"%s",out);else snprintf(asmpath,sizeof(asmpath),"%s.flint.s",out);
    if(compile_native(src,asmpath))return 1;
    if(emit_only)return 0;
    char cmd[8192];snprintf(cmd,sizeof(cmd),"cc -nostdlib -no-pie -Wl,--build-id=none -o '%s' '%s'",out,asmpath);
    int rc=system(cmd);if(rc!=0)return 1;unlink(asmpath);return 0;
}
